<span class="wpstg-notice-alert" style="margin-top:20px;">
    <?php echo __("WordPress Multisite is currently not supported!", "wpstg")?>
</span>