<div class="error">
    <p>
        <?php
        echo sprintf( __(
                        'You have no license key entered. WP Staging Pro needs a valid license key to be activated. You can purchase the license from here:' .
                        '<br/> <a href="%1$s" target="_blank">%1$s</a>', 'wpstg'), 'https://wp-staging.com' 
        );
        ?>
    </p>
</div>