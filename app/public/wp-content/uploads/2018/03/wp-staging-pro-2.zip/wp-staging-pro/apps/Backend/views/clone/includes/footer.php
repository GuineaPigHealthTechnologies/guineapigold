<div id="wpstg-error-wrapper">
    <div id="wpstg-error-details"></div>
</div>